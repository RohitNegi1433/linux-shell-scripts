#!/bin/bash

<< comment
loyalty test for nibba nibi 
with arguments veriable
comment

echo "if nibba will see to nibbi then he will turn"

read girl

if [ $girl == "nibbi" ]; then

   echo "loyal"
   echo "niibbi will make a folder"
   mkdir nibbloyaltestpass

else
   echo "nibaa move away"

fi
