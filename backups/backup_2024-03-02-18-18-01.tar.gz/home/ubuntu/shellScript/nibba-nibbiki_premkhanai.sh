#!/bin/bash


#Nibba nibbi ki ajab gazab prem kahani

echo "Hello Nibbi"

echo "hi nibba"


echo "nibba - can we got out for coffe"

date

echo "nibbi = yes sure"

echo "nibba =i am waiting for you in coffe table"

uptime

echo " still i am waiting "

echo " nibbi = i am doing some important work creating files in desktop"

ls /home/ubuntu

echo "i willcreate files in your desktop"
mkdir nibbanibbi

echo " nibba = where you are busy"
echo "i am busy with somone"
read  someone
echo  $someone

echo "but $someone you are busy with $1"
echo " not iam not its less $#"

echo $@
